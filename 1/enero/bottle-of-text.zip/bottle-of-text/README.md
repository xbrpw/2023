# Bottle of Text

A Pen created on CodePen.io. Original URL: [https://codepen.io/jkantner/pen/PoNYmZw](https://codepen.io/jkantner/pen/PoNYmZw).

A spinning water bottle made of text and CSS 3D transforms