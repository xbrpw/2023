# CSS Sajha Bus

A Pen created on CodePen.io. Original URL: [https://codepen.io/nirazanbasnet/pen/BdPOjN](https://codepen.io/nirazanbasnet/pen/BdPOjN).

