# Divtober'22 #13: Forever

A Pen created on CodePen.io. Original URL: [https://codepen.io/alvaromontoro/pen/vYjvzPO](https://codepen.io/alvaromontoro/pen/vYjvzPO).

Cartoon with the silhouette of a person carrying a boulder uphill forever (the myth of Sisyphus, who was punished to carry a boulder up a mountain, just for the boulder to roll down every night, so he had to repeat the process every day forever.)

Drawing in CSS + a single HTML element.