# Hell over ocean

A Pen created on CodePen.io. Original URL: [https://codepen.io/Yakudoo/pen/prYmKj](https://codepen.io/Yakudoo/pen/prYmKj).

Exploring shaders, noise and fbm. The result is scary.