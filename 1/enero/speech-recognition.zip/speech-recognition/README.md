# Speech Recognition

A Pen created on CodePen.io. Original URL: [https://codepen.io/ivillamil/pen/wGKELe](https://codepen.io/ivillamil/pen/wGKELe).

This demos shows how to recognize speech commands from the user using the **Annyang** library.

Sadly, at the moment speech recognition is only supported by Chrome and opera.