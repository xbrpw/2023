# Stop Sign at Night

A Pen created on CodePen.io. Original URL: [https://codepen.io/lonekorean/pen/nyjrzP](https://codepen.io/lonekorean/pen/nyjrzP).

An experiment in creating a real world object with pure CSS.