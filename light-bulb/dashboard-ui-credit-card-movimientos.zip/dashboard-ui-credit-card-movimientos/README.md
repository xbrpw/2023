# Dashboard UI credit card movimientos

A Pen created on CodePen.io. Original URL: [https://codepen.io/luisangelmaciel/pen/QWBKqJa](https://codepen.io/luisangelmaciel/pen/QWBKqJa).

An example of how you can support dark mode using Tailwind CSS.

Design: https://dribbble.com/shots/14594771-Dashboard-UI