# To-do with localStorage JSON

A Pen created on CodePen.io. Original URL: [https://codepen.io/luisangelmaciel/pen/MWBjvGb](https://codepen.io/luisangelmaciel/pen/MWBjvGb).

